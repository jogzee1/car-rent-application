import { IHomePageState } from "../app/containters/HomePage/type";


export interface IRootAppState {
  homePage: IHomePageState;
}
