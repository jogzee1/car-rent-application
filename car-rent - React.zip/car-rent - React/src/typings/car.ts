export interface ICar {
    thumbnailSrc: string;
    name: string;
    mileage: string;
    gearType: string;
    dailyPrice: number;
    monthlyPrice: number;
    gas: string;
}